<?php
    $host_db = "localhost";
    $user_db = "root";
    $password_db = "root";
    $database_db = "NootNoot";
        $table1_db = "table1";
        $table2_db = "blog";
        $table3_db =  "images_tbl";
        $table4_db = "questions"
?>